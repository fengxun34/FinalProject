document.getElementById('rating-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get the selected rating
    let selectedRating = document.querySelector('input[name="rating"]:checked');
    let reviewText = document.querySelector('textarea[name="review"]').value.trim(); // Get the review text
    
    // Display feedback
    if (selectedRating) {
        let ratingValue = selectedRating.value;
        let feedbackMessage = `您已給予 ${ratingValue} 顆星的評價！`;

        // Show rating feedback
        let feedbackElement = document.getElementById('rating-feedback');
        feedbackElement.textContent = feedbackMessage;
        
        // Optionally show the review content
        if (reviewText) {
            let reviewMessage = ` 內容：${reviewText}`;
            // Create a new line for the review text
            let reviewElement = document.createElement('p');
            reviewElement.textContent = reviewMessage;
            feedbackElement.appendChild(reviewElement);
        }
        
        // Show the feedback message
        feedbackElement.style.display = 'block';
    } else {
        alert("請選擇評價星數！");
    }
});
